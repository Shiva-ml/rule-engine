const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const otpGenerator = require('otp-generator');



const app = express();
const port = 8081;

app.use(bodyParser.urlencoded({ extended: true }));


// Temporary store for OTPs
const otps = {};



// Mock user data
const users = [
    { userName: 'john', firstname: 'John', lastname: 'Doe', email: 'john', userId: '1', roles: '', gender: 'Male'},
    { userName: 'jane', firstname: 'Jane', lastname: 'Doe', email: 'jane', userId: '2', roles: '', gender: 'Female'},
    { userName: '9449714938', firstname: 'dummy', lastname: 'dummy', email: 'dummy@test.com', userId: '2', roles: '', gender: 'Female'},
    { userName: '1234567890', firstname: 'dummy', lastname: 'dummy', email: 'dummy@test.com', userId: '2', roles: '', gender: 'Female'},

];

// Mock password store
const passwords = {
    john: '1234',
    jane: '5678',
    9449714938: '1234',
    1234567890: '1234'

};

// Mock password store
const pin_stored = {
    john: '111',
    jane: '222',
    9449714938: '1234',
    1234567890: '1234'

};

// Mock password store
const loa = {
    john: 'uppinotp',
    jane: 'up',
    9449714938: 'uppin',
    1234567890: 'upotp'

};




// Endpoint to get user by username
app.get('/users/:userName', (req, res) => {
    const user = users.find(u => u.userName === req.params.userName);
    if (user) {
        res.json(user);
        console.log('User present');
    } else {
        res.status(404).send('User not found');
        console.log('User not found');
    }
});

// Endpoint to verify user password
app.post('/users/:userName/verify-password', (req, res) => {
    console.log(`Finding user to verify the password: ${req.params.userName}`);

    const userName = req.params.userName;
    const password = req.body.password;

    console.log(`Verifying password for user: ${password}`);

    // Find the user by username and verify password
    if (passwords[userName] && passwords[userName] === password) {
        res.sendStatus(200); // Password correct
        console.log('Password verified successfully');
    } else {
        res.sendStatus(401); // Unauthorized if password incorrect
        console.log('Password verification failed');
    }
});

app.post('/users/:userName/verify-pin', (req, res) => {
    console.log(`pin verification processs started`);

    const userName = req.params.userName;
    const pin = req.body.pin;

    console.log(`Verifying pin for user: ${userName}`);

    // Find the user by username and verify password
    if (pin_stored[userName] && pin_stored[userName] === pin) {
        res.sendStatus(200); // Password correct
        console.log('Pin verified successfully');
    } else {
        res.sendStatus(401); // Unauthorized if password incorrect
        console.log('Pin verification failed');
    }
});


// Endpoint to generate OTP
app.post('/users/generate-otp', (req, res) => {
    const mobile = req.body.mobile;
    const otp = otpGenerator.generate(6, { lowerCaseAlphabets:false,upperCaseAlphabets: false, specialChars: false });

    // Store OTP temporarily (e.g., for 5 minutes)
    otps[mobile] = otp;
    setTimeout(() => { delete otps[mobile]; }, 300000); // OTP expires after 5 minutes

    console.log(`Generated OTP for user ${mobile}: ${otp}`);
    res.json({ otp });
});

// Endpoint to verify OTP
app.post('/users/verify-otp', (req, res) => {
    const mobile = req.body.mobile;
    const otp = req.body.otp;

    console.log(`Verifying OTP for user ${mobile}: ${otp}`);

    // Verify OTP
    if (otps[mobile] && otps[mobile] === otp) {
        res.sendStatus(200); // OTP correct
        console.log('OTP verified successfully');
    } else {
        res.sendStatus(401); // Unauthorized if OTP incorrect
        console.log('OTP verification failed');
    }
});



app.post('/users/:userName/verify-moa', (req, res) => {
    const userName = req.params.userName;
    const DeviceData = req.body.DeviceData;


    if (loa[userName]) {
        // Create a JSON object to send as response
        const responseObject = {
            success: true,
            moa: loa[userName]  // Replace this with your actual MOA value
        };

        // Send the JSON response
        res.status(200).json(responseObject);
        console.log('MOA obtained successfully');
        console.log(DeviceData);

    } else {
        // Send a JSON response with an error message
        res.status(401).json({
            success: false,
            message: 'MOA obtaining failed'
        });
        console.log('MOA obtaining failed');
    }
});




// Endpoint to search users
app.get('/users/search', (req, res) => {
    const query = req.query.query || '';
    const firstResult = parseInt(req.query.firstResult) || 0;
    const maxResults = parseInt(req.query.maxResults) || users.length;

    const result = users.filter(u => 
        u.userName.includes(query) || 
        u.firstname.includes(query) ||
        u.lastname.includes(query) ||
        u.email.includes(query)
    ).slice(firstResult, firstResult + maxResults);

    res.json(result);
});

app.listen(port, () => {
    console.log(`User service mock server listening at http://localhost:${port}`);
});