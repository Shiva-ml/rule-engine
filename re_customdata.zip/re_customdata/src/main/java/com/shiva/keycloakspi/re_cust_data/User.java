package com.shiva.keycloakspi.re_cust_data;

import com.fasterxml.jackson.annotation.JsonProperty;

public class User {
    @JsonProperty("success")
    private Boolean Success;

    @JsonProperty("moa")
    private String moa;




    public Boolean getmoastatus() {
        return Success;
    }

    public void setLastName(Boolean Success) {
        this.Success = Success;
    }


    public String getmoavalue() {
        return moa;
    }

    public void setLastName(String moa) {
        this.moa = moa;
    }


}
