package com.shiva.keycloakspi.re_cust_data;

import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;
import org.keycloak.broker.provider.util.SimpleHttp;
import org.keycloak.models.KeycloakSession;

public class UserService {

    private final KeycloakSession session;
    private static final Logger LOGGER = Logger.getLogger(UserService.class);

    public UserService(KeycloakSession session) {
        this.session = session;

    }

    public String verifymoa(String username,String DeviceData) {
        String MOA = "null";
        User user = null;

        try {
            SimpleHttp.Response response = SimpleHttp.doPost("http://localhost:8081/users/" + username + "/verify-moa", session)
                    .param("DeviceData", DeviceData)
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .asResponse();  // Send the request and get the response

            if (response.getStatus() == Response.Status.OK.getStatusCode()) {
                user = response.asJson(User.class);
                MOA = user.getmoavalue();
            }
        } catch (Exception e) {
            LOGGER.error("Error finding MOA", e);
        }
        return MOA;
    }



}