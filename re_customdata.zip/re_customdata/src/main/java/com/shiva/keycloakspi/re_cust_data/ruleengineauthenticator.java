package com.shiva.keycloakspi.re_cust_data;

import org.jboss.logging.Logger;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.authenticators.conditional.ConditionalAuthenticator;
import org.keycloak.models.*;

import java.util.List;
import java.util.Map;

public class ruleengineauthenticator implements ConditionalAuthenticator {

    private final UserService userService;
    private static final Logger LOGGER = Logger.getLogger(ruleengineauthenticator.class);


    public ruleengineauthenticator(UserService userService) {
        this.userService = userService;
    }

    @Override
    public boolean matchCondition(AuthenticationFlowContext context) {
        UserModel userModel = context.getUser();
        AuthenticatorConfigModel config = context.getAuthenticatorConfig();
        KeycloakSession session = context.getSession();
        String LOA = (config.getConfig().get("LOA"));
        LOGGER.infof("the recieved LOA is : %s", LOA);
        String customClaimValue = extractClaim(session);

        LOGGER.infof("the recieved moa method is : %s", customClaimValue);


        String MOA = userService.verifymoa(userModel.getUsername(),customClaimValue);


        LOGGER.infof("the recieved moa method is : %s", MOA);
        if (MOA.contains("pin") & LOA.equals("3")) {
            LOGGER.info("i recieved pin moa method");
            return true;
        } else if (MOA.contains("otp") & LOA.equals("2")) {
            LOGGER.info("i recieved otp moa method");
            return true;

        } else if (MOA.contains("null") & LOA.equals("1")) {
            LOGGER.info("i recieved nothing");
            return true;
        } else {
            LOGGER.info("condition failed");
            return false;
        }

    }

    private String getAllowedPrefix(AuthenticationFlowContext context) {
        AuthenticatorConfigModel configModel = context.getAuthenticatorConfig();
        Map<String, String> config = configModel.getConfig();
        return config.get(ruleengineauthenticatorfactory.PREFIX);
    }

    private String extractClaim(KeycloakSession keycloakSession) {
        List<String> headerValueList = keycloakSession.getContext().getRequestHeaders().getRequestHeaders().get("User-Agent");

        // Log the entire header value list
        LOGGER.info("Header value list retrieved: " + headerValueList);

        if (headerValueList != null && !headerValueList.isEmpty()) {
            String claimJsonStr = headerValueList.get(0); // Use the first header value as plain text
            LOGGER.info("First header value retrieved: " + claimJsonStr);
            return claimJsonStr;
        } else {
            LOGGER.warn("Header value list is empty or null");
            return null;
        }
    }

    @Override
    public void action(AuthenticationFlowContext authenticationFlowContext) {

    }

    @Override
    public boolean requiresUser() {
        return false;
    }

    @Override
    public void setRequiredActions(KeycloakSession keycloakSession, RealmModel realmModel, UserModel userModel) {

    }

    @Override
    public void close() {

    }
}
