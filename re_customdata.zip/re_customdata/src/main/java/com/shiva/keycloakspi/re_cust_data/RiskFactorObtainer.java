package com.shiva.keycloakspi.re_cust_data;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;
import org.keycloak.broker.provider.util.SimpleHttp;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.ProtocolMapperModel;
import org.keycloak.protocol.oidc.mappers.*;
import org.keycloak.provider.ProviderConfigProperty;

import java.util.ArrayList;
import java.util.List;

public class RiskFactorObtainer extends AbstractOIDCProtocolMapper
        implements OIDCAccessTokenMapper, OIDCIDTokenMapper, UserInfoTokenMapper {

    private final KeycloakSession session;
    private static final Logger LOGGER = Logger.getLogger(RiskFactorObtainer.class);

    private static final List<ProviderConfigProperty> configProperties = new ArrayList<>();
    private static final String HEADER_NAME = "header.name";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public RiskFactorObtainer(KeycloakSession session) {
        this.session = session;

    }
    static {
        ProviderConfigProperty headerNameProperty = new ProviderConfigProperty();
        headerNameProperty.setName(HEADER_NAME);
        headerNameProperty.setLabel("Header Name");
        headerNameProperty.setType(ProviderConfigProperty.STRING_TYPE);
        headerNameProperty.setHelpText("Name of the header to extract the claim from");
        configProperties.add(headerNameProperty);

        OIDCAttributeMapperHelper.addIncludeInTokensConfig(configProperties, RiskFactorObtainer.class);
    }

    public String verifymoa(String username) {
        String MOA = "null";
        User user = null;

        try {
            SimpleHttp.Response response = SimpleHttp.doGet("http://localhost:8081/users/" + username + "/verify-moa", session)
                    .asResponse();  // Send the request and get the response

            if (response.getStatus() == Response.Status.OK.getStatusCode()) {
                user = response.asJson(User.class);
                MOA = user.getmoavalue();
            }
        } catch (Exception e) {
            LOGGER.error("Error finding MOA", e);
        }
        return MOA;
    }

    private String extractClaim(ProtocolMapperModel mappingModel, KeycloakSession keycloakSession) {
        String headerName = mappingModel.getConfig().get(HEADER_NAME);
        LOGGER.info("Extracting claim from header: " + headerName);

        List<String> headerValueList = keycloakSession.getContext().getRequestHeaders().getRequestHeaders().get(headerName);
        if (headerValueList == null || headerValueList.isEmpty()) {
            LOGGER.info("Header " + headerName + " not found.");
            return null;
        }

        String claimJsonStr = headerValueList.get(0); // Use the header value as plain text
        LOGGER.info("Header value retrieved: " + claimJsonStr);

        return claimJsonStr;
    }


    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return configProperties;
    }

    @Override
    public String getId() {
        return "final-custom-header-to-claim-mapper";
    }

    @Override
    public String getDisplayType() {
        return "final Custom custom Header to Claim Mapper";
    }

    @Override
    public String getDisplayCategory() {
        return "Token Mapper";
    }

    @Override
    public String getHelpText() {
        return "Maps a claim from a custom header into the token.";
    }

    @Override
    public String getProtocol() {
        return "openid-connect";
    }
}